import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  HomeIcon, 
  CubeIcon, 
  TagIcon, 
  DocumentTextIcon, 
  ChartBarIcon,
  UserIcon,
  LogoutIcon,
  MenuIcon,
  XIcon,
  BellIcon
} from '@heroicons/react/24/outline';

const Layout = ({ children, currentPage, setCurrentPage }) => {
  const { user, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navigation = [
    { name: 'Dashboard', icon: HomeIcon, page: 'dashboard', roles: ['admin', 'vendedor', 'inventario', 'viewer'] },
    { name: 'Productos', icon: CubeIcon, page: 'products', roles: ['admin', 'inventario', 'viewer'] },
    { name: 'Categorías', icon: TagIcon, page: 'categories', roles: ['admin', 'inventario'] },
    { name: 'Facturas', icon: DocumentTextIcon, page: 'invoices', roles: ['admin', 'vendedor', 'viewer'] },
    { name: 'Reportes', icon: ChartBarIcon, page: 'reports', roles: ['admin', 'vendedor'] },
  ];

  const filteredNavigation = navigation.filter(item => 
    item.roles.includes(user?.role || 'viewer')
  );

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar para móvil */}
      <div className={`fixed inset-0 z-40 md:hidden ${sidebarOpen ? 'block' : 'hidden'}`}>
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={() => setSidebarOpen(false)} />
        <div className="relative flex flex-col w-64 bg-white h-full shadow-xl">
          <div className="flex items-center justify-between p-4 border-b">
            <h1 className="text-xl font-bold text-gray-900">FacturApp</h1>
            <button onClick={() => setSidebarOpen(false)} className="p-2 rounded-md hover:bg-gray-100">
              <XIcon className="w-6 h-6" />
            </button>
          </div>
          <nav className="flex-1 px-4 py-4 space-y-2">
            {filteredNavigation.map((item) => (
              <button
                key={item.name}
                onClick={() => {
                  setCurrentPage(item.page);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  currentPage === item.page
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.name}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Sidebar para desktop */}
      <div className="hidden md:fixed md:inset-y-0 md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-1 min-h-0 bg-white shadow-lg">
          <div className="flex items-center h-16 px-6 border-b bg-gradient-to-r from-blue-600 to-purple-600">
            <h1 className="text-xl font-bold text-white">FacturApp</h1>
          </div>
          <nav className="flex-1 px-4 py-6 space-y-2">
            {filteredNavigation.map((item) => (
              <button
                key={item.name}
                onClick={() => setCurrentPage(item.page)}
                className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  currentPage === item.page
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.name}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Contenido principal */}
      <div className="md:pl-64">
        {/* Header */}
        <div className="bg-white shadow-sm border-b">
          <div className="flex items-center justify-between px-4 py-4">
            <div className="flex items-center">
              <button
                onClick={() => setSidebarOpen(true)}
                className="p-2 rounded-md text-gray-500 hover:bg-gray-100 md:hidden"
              >
                <MenuIcon className="w-6 h-6" />
              </button>
              <h2 className="ml-4 text-xl font-semibold text-gray-900 capitalize">
                {currentPage === 'dashboard' ? 'Panel de Control' : currentPage}
              </h2>
            </div>
            
            <div className="flex items-center space-x-4">
              <button className="p-2 rounded-full text-gray-500 hover:bg-gray-100">
                <BellIcon className="w-6 h-6" />
              </button>
              
              <div className="flex items-center space-x-3">
                <div className="hidden sm:block text-right">
                  <p className="text-sm font-medium text-gray-900">{user?.full_name}</p>
                  <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
                </div>
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                  <UserIcon className="w-5 h-5 text-white" />
                </div>
                <button
                  onClick={handleLogout}
                  className="p-2 rounded-full text-gray-500 hover:bg-gray-100"
                >
                  <LogoutIcon className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Contenido de la página */}
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;