import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import {
  CubeIcon,
  TagIcon,
  DocumentTextIcon,
  CurrencyDollarIcon,
  ExclamationTriangleIcon,
  TrendingUpIcon,
  UsersIcon,
  ChartBarIcon
} from '@heroicons/react/24/outline';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Dashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API}/stats/dashboard`);
      setStats(response.data);
    } catch (error) {
      setError('Error al cargar las estadísticas');
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-md p-4">
        <div className="flex">
          <ExclamationTriangleIcon className="h-5 w-5 text-red-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">Error</h3>
            <div className="mt-2 text-sm text-red-700">{error}</div>
          </div>
        </div>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Total Productos',
      value: stats?.total_products || 0,
      icon: CubeIcon,
      color: 'bg-blue-500',
      textColor: 'text-blue-600'
    },
    {
      title: 'Categorías',
      value: stats?.total_categories || 0,
      icon: TagIcon,
      color: 'bg-green-500',
      textColor: 'text-green-600'
    },
    {
      title: 'Facturas',
      value: stats?.total_invoices || 0,
      icon: DocumentTextIcon,
      color: 'bg-purple-500',
      textColor: 'text-purple-600'
    },
    {
      title: 'Ventas del Mes',
      value: `$${(stats?.monthly_sales || 0).toLocaleString()}`,
      icon: CurrencyDollarIcon,
      color: 'bg-yellow-500',
      textColor: 'text-yellow-600'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Saludo personalizado */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">
          ¡Hola, {user?.full_name}! 👋
        </h1>
        <p className="text-blue-100">
          Bienvenido al panel de control de tu sistema de facturación
        </p>
      </div>

      {/* Tarjetas de estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-200"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{card.title}</p>
                <p className={`text-2xl font-bold ${card.textColor}`}>{card.value}</p>
              </div>
              <div className={`p-3 rounded-full ${card.color}`}>
                <card.icon className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Productos con stock bajo */}
      {stats?.low_stock_products > 0 && (
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
          <div className="flex items-center mb-4">
            <ExclamationTriangleIcon className="w-6 h-6 text-orange-600 mr-2" />
            <h3 className="text-lg font-semibold text-orange-800">
              Productos con Stock Bajo
            </h3>
          </div>
          <p className="text-orange-700 mb-4">
            {stats.low_stock_products} productos tienen menos de 10 unidades en stock
          </p>
          <div className="space-y-2">
            {stats.low_stock_items?.slice(0, 5).map((product, index) => (
              <div key={index} className="flex justify-between items-center bg-white p-3 rounded">
                <span className="font-medium">{product.name}</span>
                <span className="text-orange-600 font-bold">{product.stock} unidades</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Acciones rápidas */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Acciones Rápidas
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {(user?.role === 'admin' || user?.role === 'inventario') && (
            <button className="flex items-center justify-center p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors">
              <CubeIcon className="w-6 h-6 text-blue-600 mr-2" />
              <span className="text-blue-700 font-medium">Agregar Producto</span>
            </button>
          )}
          
          {(user?.role === 'admin' || user?.role === 'vendedor') && (
            <button className="flex items-center justify-center p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors">
              <DocumentTextIcon className="w-6 h-6 text-green-600 mr-2" />
              <span className="text-green-700 font-medium">Nueva Factura</span>
            </button>
          )}
          
          <button className="flex items-center justify-center p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors">
            <ChartBarIcon className="w-6 h-6 text-purple-600 mr-2" />
            <span className="text-purple-700 font-medium">Ver Reportes</span>
          </button>
        </div>
      </div>

      {/* Gráfico de ventas simple */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Resumen de Ventas
        </h3>
        <div className="flex items-center justify-center h-32 bg-gray-50 rounded-lg">
          <div className="text-center">
            <TrendingUpIcon className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500">Gráfico de ventas próximamente</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;