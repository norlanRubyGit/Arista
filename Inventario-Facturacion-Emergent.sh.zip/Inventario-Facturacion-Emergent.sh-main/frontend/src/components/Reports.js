import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import {
  ChartBarIcon,
  DocumentTextIcon,
  CurrencyDollarIcon,
  CalendarIcon,
  ArrowDownTrayIcon
} from '@heroicons/react/24/outline';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Reports = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [invoices, setInvoices] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });

  useEffect(() => {
    fetchData();
  }, [dateRange]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [statsResponse, invoicesResponse, productsResponse] = await Promise.all([
        axios.get(`${API}/stats/dashboard`),
        axios.get(`${API}/invoices`),
        axios.get(`${API}/products`)
      ]);

      setStats(statsResponse.data);
      setInvoices(invoicesResponse.data);
      setProducts(productsResponse.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getFilteredInvoices = () => {
    return invoices.filter(invoice => {
      const invoiceDate = new Date(invoice.created_at);
      const startDate = new Date(dateRange.start);
      const endDate = new Date(dateRange.end);
      endDate.setHours(23, 59, 59, 999);
      
      return invoiceDate >= startDate && invoiceDate <= endDate;
    });
  };

  const getSalesReport = () => {
    const filteredInvoices = getFilteredInvoices();
    const paidInvoices = filteredInvoices.filter(invoice => invoice.status === 'pagada');
    
    const totalSales = paidInvoices.reduce((sum, invoice) => sum + invoice.total, 0);
    const totalInvoices = paidInvoices.length;
    const averageTicket = totalInvoices > 0 ? totalSales / totalInvoices : 0;

    return {
      totalSales,
      totalInvoices,
      averageTicket,
      paidInvoices
    };
  };

  const getTopProducts = () => {
    const filteredInvoices = getFilteredInvoices();
    const paidInvoices = filteredInvoices.filter(invoice => invoice.status === 'pagada');
    
    const productSales = {};
    
    paidInvoices.forEach(invoice => {
      invoice.items.forEach(item => {
        if (productSales[item.product_id]) {
          productSales[item.product_id].quantity += item.quantity;
          productSales[item.product_id].total += item.total;
        } else {
          productSales[item.product_id] = {
            name: item.product_name,
            quantity: item.quantity,
            total: item.total
          };
        }
      });
    });

    return Object.entries(productSales)
      .map(([id, data]) => ({ id, ...data }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 10);
  };

  const getStatusReport = () => {
    const filteredInvoices = getFilteredInvoices();
    const statusCount = {};
    
    filteredInvoices.forEach(invoice => {
      statusCount[invoice.status] = (statusCount[invoice.status] || 0) + 1;
    });

    return Object.entries(statusCount).map(([status, count]) => ({
      status,
      count,
      percentage: filteredInvoices.length > 0 ? (count / filteredInvoices.length) * 100 : 0
    }));
  };

  const exportToCSV = () => {
    const salesReport = getSalesReport();
    const topProducts = getTopProducts();
    
    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Sales summary
    csvContent += "REPORTE DE VENTAS\n";
    csvContent += `Período,${dateRange.start} al ${dateRange.end}\n`;
    csvContent += `Total de Ventas,$${salesReport.totalSales.toLocaleString()}\n`;
    csvContent += `Número de Facturas,${salesReport.totalInvoices}\n`;
    csvContent += `Ticket Promedio,$${salesReport.averageTicket.toLocaleString()}\n\n`;
    
    // Top products
    csvContent += "PRODUCTOS MÁS VENDIDOS\n";
    csvContent += "Producto,Cantidad,Total\n";
    topProducts.forEach(product => {
      csvContent += `${product.name},${product.quantity},$${product.total.toLocaleString()}\n`;
    });
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `reporte_ventas_${dateRange.start}_${dateRange.end}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const salesReport = getSalesReport();
  const topProducts = getTopProducts();
  const statusReport = getStatusReport();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Reportes</h1>
        <button
          onClick={exportToCSV}
          className="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
        >
          <ArrowDownTrayIcon className="w-4 h-4 mr-2" />
          Exportar CSV
        </button>
      </div>

      {/* Date Range Filter */}
      <div className="bg-white p-4 rounded-lg shadow-sm border">
        <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-2">
            <CalendarIcon className="w-5 h-5 text-gray-400" />
            <label className="text-sm font-medium text-gray-700">Período:</label>
          </div>
          <div className="flex items-center space-x-2">
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <span className="text-gray-500">al</span>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Sales Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total de Ventas</p>
              <p className="text-2xl font-bold text-green-600">
                ${salesReport.totalSales.toLocaleString()}
              </p>
            </div>
            <div className="p-3 rounded-full bg-green-100">
              <CurrencyDollarIcon className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Facturas Pagadas</p>
              <p className="text-2xl font-bold text-blue-600">
                {salesReport.totalInvoices}
              </p>
            </div>
            <div className="p-3 rounded-full bg-blue-100">
              <DocumentTextIcon className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Ticket Promedio</p>
              <p className="text-2xl font-bold text-purple-600">
                ${salesReport.averageTicket.toLocaleString()}
              </p>
            </div>
            <div className="p-3 rounded-full bg-purple-100">
              <ChartBarIcon className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Top Products */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Productos Más Vendidos
        </h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Producto
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cantidad Vendida
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total de Ventas
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {topProducts.map((product, index) => (
                <tr key={product.id} className={index < 3 ? 'bg-yellow-50' : ''}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {index < 3 && (
                        <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-yellow-100 text-yellow-800 text-xs font-medium mr-3">
                          {index + 1}
                        </span>
                      )}
                      <div className="text-sm font-medium text-gray-900">
                        {product.name}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {product.quantity} unidades
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${product.total.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice Status Report */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Estado de Facturas
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {statusReport.map((status, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-600 capitalize">
                  {status.status}
                </span>
                <span className="text-lg font-bold text-gray-900">
                  {status.count}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${status.percentage}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {status.percentage.toFixed(1)}% del total
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Low Stock Alert */}
      {stats?.low_stock_products > 0 && (
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-orange-800 mb-2">
            Alerta de Inventario
          </h3>
          <p className="text-orange-700 mb-4">
            {stats.low_stock_products} productos tienen stock bajo (menos de 10 unidades)
          </p>
          <div className="space-y-2">
            {stats.low_stock_items?.slice(0, 5).map((product, index) => (
              <div key={index} className="flex justify-between items-center bg-white p-3 rounded border">
                <span className="font-medium text-gray-900">{product.name}</span>
                <span className="text-orange-600 font-bold">{product.stock} unidades</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Reports;