from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timedelta
from passlib.context import CryptContext
import jwt
from enum import Enum


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Configuración de seguridad
SECRET_KEY = os.environ.get('SECRET_KEY', 'tu-clave-secreta-muy-segura-aqui')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Configuración de encriptación de contraseñas
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI(title="Sistema de Facturación e Inventario", version="1.0.0")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# =============================================
# ENUMERACIONES (Tipos de datos específicos)
# =============================================

class UserRole(str, Enum):
    """Roles de usuario en el sistema"""
    ADMIN = "admin"           # Administrador: acceso total
    VENDEDOR = "vendedor"     # Vendedor: puede crear facturas
    INVENTARIO = "inventario" # Inventario: maneja productos
    VIEWER = "viewer"         # Solo lectura

class InvoiceStatus(str, Enum):
    """Estados de las facturas"""
    DRAFT = "borrador"        # Borrador
    PENDING = "pendiente"     # Pendiente de pago
    PAID = "pagada"          # Pagada
    CANCELLED = "cancelada"   # Cancelada

# =============================================
# MODELOS DE DATOS
# =============================================

class User(BaseModel):
    """Modelo para usuarios del sistema"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    full_name: str
    role: UserRole = UserRole.VIEWER
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class UserCreate(BaseModel):
    """Modelo para crear usuarios"""
    email: EmailStr
    full_name: str
    password: str
    role: UserRole = UserRole.VIEWER

class UserLogin(BaseModel):
    """Modelo para login de usuarios"""
    email: EmailStr
    password: str

class Token(BaseModel):
    """Modelo para tokens de autenticación"""
    access_token: str
    token_type: str

class Category(BaseModel):
    """Modelo para categorías de productos"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: Optional[str] = None
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class CategoryCreate(BaseModel):
    """Modelo para crear categorías"""
    name: str
    description: Optional[str] = None

class Product(BaseModel):
    """Modelo para productos"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: Optional[str] = None
    price: float
    stock: int = 0
    category_id: Optional[str] = None
    image_base64: Optional[str] = None  # Imagen en formato base64
    custom_fields: Optional[Dict[str, Any]] = {}  # Campos personalizables
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class ProductCreate(BaseModel):
    """Modelo para crear productos"""
    name: str
    description: Optional[str] = None
    price: float
    stock: int = 0
    category_id: Optional[str] = None
    image_base64: Optional[str] = None
    custom_fields: Optional[Dict[str, Any]] = {}

class InvoiceItem(BaseModel):
    """Item de factura"""
    product_id: str
    product_name: str
    quantity: int
    unit_price: float
    total: float

class Invoice(BaseModel):
    """Modelo para facturas"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    invoice_number: str
    customer_name: str
    customer_email: Optional[str] = None
    items: List[InvoiceItem] = []
    subtotal: float = 0.0
    tax: float = 0.0
    total: float = 0.0
    status: InvoiceStatus = InvoiceStatus.DRAFT
    created_by: str  # ID del usuario que creó la factura
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class InvoiceCreate(BaseModel):
    """Modelo para crear facturas"""
    customer_name: str
    customer_email: Optional[str] = None
    items: List[InvoiceItem] = []

# =============================================
# FUNCIONES DE UTILIDAD
# =============================================

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifica si la contraseña es correcta"""
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    """Encripta una contraseña"""
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Crea un token de acceso"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Obtiene el usuario actual desde el token"""
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token inválido",
                headers={"WWW-Authenticate": "Bearer"},
            )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    user = await db.users.find_one({"id": user_id})
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuario no encontrado",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return User(**user)

# =============================================
# ENDPOINTS DE AUTENTICACIÓN
# =============================================

@api_router.post("/auth/register", response_model=User)
async def register_user(user_data: UserCreate):
    """Registra un nuevo usuario"""
    # Verificar si el email ya existe
    existing_user = await db.users.find_one({"email": user_data.email})
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El email ya está registrado"
        )
    
    # Crear el usuario
    hashed_password = get_password_hash(user_data.password)
    user_dict = user_data.dict()
    user_dict.pop("password")
    user_obj = User(**user_dict)
    
    # Crear el documento para la base de datos con la contraseña hasheada
    user_doc = user_obj.dict()
    user_doc["hashed_password"] = hashed_password
    
    await db.users.insert_one(user_doc)
    return user_obj

@api_router.post("/auth/login", response_model=Token)
async def login_user(user_credentials: UserLogin):
    """Inicia sesión de usuario"""
    user = await db.users.find_one({"email": user_credentials.email})
    if not user or not verify_password(user_credentials.password, user["hashed_password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email o contraseña incorrectos",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["id"]}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@api_router.get("/auth/me", response_model=User)
async def get_current_user_info(current_user: User = Depends(get_current_user)):
    """Obtiene la información del usuario actual"""
    return current_user

# =============================================
# ENDPOINTS DE CATEGORÍAS
# =============================================

@api_router.get("/categories", response_model=List[Category])
async def get_categories(current_user: User = Depends(get_current_user)):
    """Obtiene todas las categorías"""
    categories = await db.categories.find({"is_active": True}).to_list(1000)
    return [Category(**category) for category in categories]

@api_router.post("/categories", response_model=Category)
async def create_category(category_data: CategoryCreate, current_user: User = Depends(get_current_user)):
    """Crea una nueva categoría"""
    # Solo admin puede crear categorías
    if current_user.role not in [UserRole.ADMIN]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permisos para crear categorías"
        )
    
    category_obj = Category(**category_data.dict())
    await db.categories.insert_one(category_obj.dict())
    return category_obj

@api_router.put("/categories/{category_id}", response_model=Category)
async def update_category(category_id: str, category_data: CategoryCreate, current_user: User = Depends(get_current_user)):
    """Actualiza una categoría"""
    if current_user.role not in [UserRole.ADMIN]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permisos para actualizar categorías"
        )
    
    category = await db.categories.find_one({"id": category_id})
    if not category:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Categoría no encontrada"
        )
    
    update_data = category_data.dict()
    update_data["updated_at"] = datetime.utcnow()
    
    await db.categories.update_one(
        {"id": category_id},
        {"$set": update_data}
    )
    
    updated_category = await db.categories.find_one({"id": category_id})
    return Category(**updated_category)

@api_router.delete("/categories/{category_id}")
async def delete_category(category_id: str, current_user: User = Depends(get_current_user)):
    """Elimina una categoría (soft delete)"""
    if current_user.role not in [UserRole.ADMIN]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permisos para eliminar categorías"
        )
    
    category = await db.categories.find_one({"id": category_id})
    if not category:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Categoría no encontrada"
        )
    
    await db.categories.update_one(
        {"id": category_id},
        {"$set": {"is_active": False, "updated_at": datetime.utcnow()}}
    )
    
    return {"message": "Categoría eliminada correctamente"}

# =============================================
# ENDPOINTS DE PRODUCTOS
# =============================================

@api_router.get("/products", response_model=List[Product])
async def get_products(current_user: User = Depends(get_current_user)):
    """Obtiene todos los productos"""
    products = await db.products.find({"is_active": True}).to_list(1000)
    return [Product(**product) for product in products]

@api_router.get("/products/{product_id}", response_model=Product)
async def get_product(product_id: str, current_user: User = Depends(get_current_user)):
    """Obtiene un producto específico"""
    product = await db.products.find_one({"id": product_id, "is_active": True})
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Producto no encontrado"
        )
    return Product(**product)

@api_router.post("/products", response_model=Product)
async def create_product(product_data: ProductCreate, current_user: User = Depends(get_current_user)):
    """Crea un nuevo producto"""
    # Admin e Inventario pueden crear productos
    if current_user.role not in [UserRole.ADMIN, UserRole.INVENTARIO]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permisos para crear productos"
        )
    
    # Verificar que la categoría existe si se especifica
    if product_data.category_id:
        category = await db.categories.find_one({"id": product_data.category_id, "is_active": True})
        if not category:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Categoría no encontrada"
            )
    
    product_obj = Product(**product_data.dict())
    await db.products.insert_one(product_obj.dict())
    return product_obj

@api_router.put("/products/{product_id}", response_model=Product)
async def update_product(product_id: str, product_data: ProductCreate, current_user: User = Depends(get_current_user)):
    """Actualiza un producto"""
    if current_user.role not in [UserRole.ADMIN, UserRole.INVENTARIO]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permisos para actualizar productos"
        )
    
    product = await db.products.find_one({"id": product_id, "is_active": True})
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Producto no encontrado"
        )
    
    # Verificar que la categoría existe si se especifica
    if product_data.category_id:
        category = await db.categories.find_one({"id": product_data.category_id, "is_active": True})
        if not category:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Categoría no encontrada"
            )
    
    update_data = product_data.dict()
    update_data["updated_at"] = datetime.utcnow()
    
    await db.products.update_one(
        {"id": product_id},
        {"$set": update_data}
    )
    
    updated_product = await db.products.find_one({"id": product_id})
    return Product(**updated_product)

@api_router.delete("/products/{product_id}")
async def delete_product(product_id: str, current_user: User = Depends(get_current_user)):
    """Elimina un producto (soft delete)"""
    if current_user.role not in [UserRole.ADMIN, UserRole.INVENTARIO]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permisos para eliminar productos"
        )
    
    product = await db.products.find_one({"id": product_id, "is_active": True})
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Producto no encontrado"
        )
    
    await db.products.update_one(
        {"id": product_id},
        {"$set": {"is_active": False, "updated_at": datetime.utcnow()}}
    )
    
    return {"message": "Producto eliminado correctamente"}

# =============================================
# ENDPOINTS DE FACTURAS
# =============================================

@api_router.get("/invoices", response_model=List[Invoice])
async def get_invoices(current_user: User = Depends(get_current_user)):
    """Obtiene todas las facturas"""
    invoices = await db.invoices.find().to_list(1000)
    return [Invoice(**invoice) for invoice in invoices]

@api_router.get("/invoices/{invoice_id}", response_model=Invoice)
async def get_invoice(invoice_id: str, current_user: User = Depends(get_current_user)):
    """Obtiene una factura específica"""
    invoice = await db.invoices.find_one({"id": invoice_id})
    if not invoice:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Factura no encontrada"
        )
    return Invoice(**invoice)

@api_router.post("/invoices", response_model=Invoice)
async def create_invoice(invoice_data: InvoiceCreate, current_user: User = Depends(get_current_user)):
    """Crea una nueva factura"""
    # Admin y Vendedor pueden crear facturas
    if current_user.role not in [UserRole.ADMIN, UserRole.VENDEDOR]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permisos para crear facturas"
        )
    
    # Calcular totales
    subtotal = sum(item.total for item in invoice_data.items)
    tax = subtotal * 0.16  # 16% de IVA
    total = subtotal + tax
    
    # Generar número de factura
    invoice_count = await db.invoices.count_documents({})
    invoice_number = f"INV-{invoice_count + 1:06d}"
    
    # Crear factura
    invoice_dict = invoice_data.dict()
    invoice_dict.update({
        "invoice_number": invoice_number,
        "subtotal": subtotal,
        "tax": tax,
        "total": total,
        "created_by": current_user.id,
        "status": InvoiceStatus.DRAFT
    })
    
    invoice_obj = Invoice(**invoice_dict)
    await db.invoices.insert_one(invoice_obj.dict())
    
    # Actualizar stock de productos
    for item in invoice_data.items:
        await db.products.update_one(
            {"id": item.product_id},
            {"$inc": {"stock": -item.quantity}}
        )
    
    return invoice_obj

@api_router.put("/invoices/{invoice_id}/status")
async def update_invoice_status(invoice_id: str, status: InvoiceStatus, current_user: User = Depends(get_current_user)):
    """Actualiza el estado de una factura"""
    if current_user.role not in [UserRole.ADMIN, UserRole.VENDEDOR]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permisos para actualizar facturas"
        )
    
    invoice = await db.invoices.find_one({"id": invoice_id})
    if not invoice:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Factura no encontrada"
        )
    
    await db.invoices.update_one(
        {"id": invoice_id},
        {"$set": {"status": status, "updated_at": datetime.utcnow()}}
    )
    
    return {"message": "Estado actualizado correctamente"}

# =============================================
# ENDPOINTS DE ESTADÍSTICAS
# =============================================

@api_router.get("/stats/dashboard")
async def get_dashboard_stats(current_user: User = Depends(get_current_user)):
    """Obtiene estadísticas para el dashboard"""
    # Contar productos
    total_products = await db.products.count_documents({"is_active": True})
    
    # Contar categorías
    total_categories = await db.categories.count_documents({"is_active": True})
    
    # Contar facturas
    total_invoices = await db.invoices.count_documents({})
    
    # Ventas del mes actual
    from datetime import datetime, timedelta
    start_month = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    monthly_sales = await db.invoices.aggregate([
        {"$match": {"created_at": {"$gte": start_month}, "status": "pagada"}},
        {"$group": {"_id": None, "total": {"$sum": "$total"}}}
    ]).to_list(1)
    
    monthly_sales_total = monthly_sales[0]["total"] if monthly_sales else 0
    
    # Productos con stock bajo
    low_stock_products = await db.products.find({"stock": {"$lt": 10}, "is_active": True}).to_list(100)
    
    return {
        "total_products": total_products,
        "total_categories": total_categories,
        "total_invoices": total_invoices,
        "monthly_sales": monthly_sales_total,
        "low_stock_products": len(low_stock_products),
        "low_stock_items": [Product(**product) for product in low_stock_products]
    }

# =============================================
# ENDPOINTS ORIGINALES (para compatibilidad)
# =============================================

class StatusCheck(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class StatusCheckCreate(BaseModel):
    client_name: str

@api_router.get("/")
async def root():
    return {"message": "Sistema de Facturación e Inventario - API v1.0"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.dict()
    status_obj = StatusCheck(**status_dict)
    _ = await db.status_checks.insert_one(status_obj.dict())
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    status_checks = await db.status_checks.find().to_list(1000)
    return [StatusCheck(**status_check) for status_check in status_checks]

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
class StatusCheck(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class StatusCheckCreate(BaseModel):
    client_name: str

# Add your routes to the router instead of directly to app
@api_router.get("/")
async def root():
    return {"message": "Hello World"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.dict()
    status_obj = StatusCheck(**status_dict)
    _ = await db.status_checks.insert_one(status_obj.dict())
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    status_checks = await db.status_checks.find().to_list(1000)
    return [StatusCheck(**status_check) for status_check in status_checks]

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
