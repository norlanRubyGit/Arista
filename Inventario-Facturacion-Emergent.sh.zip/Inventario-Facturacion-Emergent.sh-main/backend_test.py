#!/usr/bin/env python3
"""
Backend API Testing Script for Sistema de Facturación e Inventario
Tests all main endpoints in the correct order with proper authentication
"""

import requests
import json
import sys
from datetime import datetime
from typing import Dict, Any, Optional

# Configuration
BASE_URL = "https://1bc68924-3adc-4a91-9748-08227c529fa6.preview.emergentagent.com/api"
HEADERS = {"Content-Type": "application/json"}

class APITester:
    def __init__(self):
        self.base_url = BASE_URL
        self.headers = HEADERS.copy()
        self.auth_token = None
        self.test_results = []
        self.created_resources = {
            'user_id': None,
            'category_id': None,
            'product_id': None,
            'invoice_id': None
        }
    
    def log_test(self, test_name: str, success: bool, details: str, response_data: Any = None):
        """Log test results"""
        result = {
            'test': test_name,
            'success': success,
            'details': details,
            'timestamp': datetime.now().isoformat(),
            'response_data': response_data
        }
        self.test_results.append(result)
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} - {test_name}: {details}")
        if response_data and not success:
            print(f"   Response: {json.dumps(response_data, indent=2)}")
    
    def make_request(self, method: str, endpoint: str, data: Dict = None) -> tuple:
        """Make HTTP request and return (success, response_data, status_code)"""
        url = f"{self.base_url}{endpoint}"
        try:
            if method.upper() == "GET":
                response = requests.get(url, headers=self.headers, timeout=30)
            elif method.upper() == "POST":
                response = requests.post(url, headers=self.headers, json=data, timeout=30)
            elif method.upper() == "PUT":
                response = requests.put(url, headers=self.headers, json=data, timeout=30)
            elif method.upper() == "DELETE":
                response = requests.delete(url, headers=self.headers, timeout=30)
            else:
                return False, {"error": f"Unsupported method: {method}"}, 0
            
            try:
                response_data = response.json()
            except:
                response_data = {"raw_response": response.text}
            
            return response.status_code < 400, response_data, response.status_code
            
        except requests.exceptions.RequestException as e:
            return False, {"error": str(e)}, 0
    
    def set_auth_token(self, token: str):
        """Set authentication token for subsequent requests"""
        self.auth_token = token
        self.headers["Authorization"] = f"Bearer {token}"
    
    def test_auth_register(self):
        """Test user registration"""
        test_data = {
            "email": "admin@facturacion.com",
            "full_name": "Administrador Principal",
            "password": "admin123456",
            "role": "admin"
        }
        
        success, response_data, status_code = self.make_request("POST", "/auth/register", test_data)
        
        if success and "id" in response_data:
            self.created_resources['user_id'] = response_data['id']
            self.log_test(
                "User Registration", 
                True, 
                f"Admin user created successfully with ID: {response_data['id']}", 
                response_data
            )
            return True
        else:
            self.log_test(
                "User Registration", 
                False, 
                f"Failed to register user. Status: {status_code}", 
                response_data
            )
            return False
    
    def test_auth_login(self):
        """Test user login"""
        test_data = {
            "email": "admin@facturacion.com",
            "password": "admin123456"
        }
        
        success, response_data, status_code = self.make_request("POST", "/auth/login", test_data)
        
        if success and "access_token" in response_data:
            self.set_auth_token(response_data["access_token"])
            self.log_test(
                "User Login", 
                True, 
                "Login successful, token obtained", 
                {"token_type": response_data.get("token_type")}
            )
            return True
        else:
            self.log_test(
                "User Login", 
                False, 
                f"Failed to login. Status: {status_code}", 
                response_data
            )
            return False
    
    def test_auth_me(self):
        """Test get current user info"""
        if not self.auth_token:
            self.log_test("Get Current User", False, "No auth token available")
            return False
        
        success, response_data, status_code = self.make_request("GET", "/auth/me")
        
        if success and "id" in response_data:
            self.log_test(
                "Get Current User", 
                True, 
                f"User info retrieved: {response_data.get('full_name')} ({response_data.get('role')})", 
                response_data
            )
            return True
        else:
            self.log_test(
                "Get Current User", 
                False, 
                f"Failed to get user info. Status: {status_code}", 
                response_data
            )
            return False
    
    def test_create_category(self):
        """Test category creation"""
        if not self.auth_token:
            self.log_test("Create Category", False, "No auth token available")
            return False
        
        test_data = {
            "name": "Electrónicos",
            "description": "Productos electrónicos y tecnológicos"
        }
        
        success, response_data, status_code = self.make_request("POST", "/categories", test_data)
        
        if success and "id" in response_data:
            self.created_resources['category_id'] = response_data['id']
            self.log_test(
                "Create Category", 
                True, 
                f"Category created successfully: {response_data['name']}", 
                response_data
            )
            return True
        else:
            self.log_test(
                "Create Category", 
                False, 
                f"Failed to create category. Status: {status_code}", 
                response_data
            )
            return False
    
    def test_get_categories(self):
        """Test get all categories"""
        if not self.auth_token:
            self.log_test("Get Categories", False, "No auth token available")
            return False
        
        success, response_data, status_code = self.make_request("GET", "/categories")
        
        if success and isinstance(response_data, list):
            self.log_test(
                "Get Categories", 
                True, 
                f"Retrieved {len(response_data)} categories", 
                {"count": len(response_data)}
            )
            return True
        else:
            self.log_test(
                "Get Categories", 
                False, 
                f"Failed to get categories. Status: {status_code}", 
                response_data
            )
            return False
    
    def test_create_product(self):
        """Test product creation"""
        if not self.auth_token:
            self.log_test("Create Product", False, "No auth token available")
            return False
        
        test_data = {
            "name": "Laptop Dell Inspiron 15",
            "description": "Laptop para uso profesional con procesador Intel i5",
            "price": 15999.99,
            "stock": 25,
            "category_id": self.created_resources.get('category_id'),
            "custom_fields": {
                "marca": "Dell",
                "modelo": "Inspiron 15 3000",
                "garantia": "1 año"
            }
        }
        
        success, response_data, status_code = self.make_request("POST", "/products", test_data)
        
        if success and "id" in response_data:
            self.created_resources['product_id'] = response_data['id']
            self.log_test(
                "Create Product", 
                True, 
                f"Product created successfully: {response_data['name']}", 
                response_data
            )
            return True
        else:
            self.log_test(
                "Create Product", 
                False, 
                f"Failed to create product. Status: {status_code}", 
                response_data
            )
            return False
    
    def test_get_products(self):
        """Test get all products"""
        if not self.auth_token:
            self.log_test("Get Products", False, "No auth token available")
            return False
        
        success, response_data, status_code = self.make_request("GET", "/products")
        
        if success and isinstance(response_data, list):
            self.log_test(
                "Get Products", 
                True, 
                f"Retrieved {len(response_data)} products", 
                {"count": len(response_data)}
            )
            return True
        else:
            self.log_test(
                "Get Products", 
                False, 
                f"Failed to get products. Status: {status_code}", 
                response_data
            )
            return False
    
    def test_get_product_by_id(self):
        """Test get specific product"""
        if not self.auth_token or not self.created_resources.get('product_id'):
            self.log_test("Get Product by ID", False, "No auth token or product ID available")
            return False
        
        product_id = self.created_resources['product_id']
        success, response_data, status_code = self.make_request("GET", f"/products/{product_id}")
        
        if success and "id" in response_data:
            self.log_test(
                "Get Product by ID", 
                True, 
                f"Product retrieved: {response_data['name']}", 
                response_data
            )
            return True
        else:
            self.log_test(
                "Get Product by ID", 
                False, 
                f"Failed to get product by ID. Status: {status_code}", 
                response_data
            )
            return False
    
    def test_create_invoice(self):
        """Test invoice creation"""
        if not self.auth_token or not self.created_resources.get('product_id'):
            self.log_test("Create Invoice", False, "No auth token or product ID available")
            return False
        
        test_data = {
            "customer_name": "María González Pérez",
            "customer_email": "maria.gonzalez@email.com",
            "items": [
                {
                    "product_id": self.created_resources['product_id'],
                    "product_name": "Laptop Dell Inspiron 15",
                    "quantity": 2,
                    "unit_price": 15999.99,
                    "total": 31999.98
                }
            ]
        }
        
        success, response_data, status_code = self.make_request("POST", "/invoices", test_data)
        
        if success and "id" in response_data:
            self.created_resources['invoice_id'] = response_data['id']
            self.log_test(
                "Create Invoice", 
                True, 
                f"Invoice created: {response_data['invoice_number']} for {response_data['customer_name']}", 
                response_data
            )
            return True
        else:
            self.log_test(
                "Create Invoice", 
                False, 
                f"Failed to create invoice. Status: {status_code}", 
                response_data
            )
            return False
    
    def test_get_invoices(self):
        """Test get all invoices"""
        if not self.auth_token:
            self.log_test("Get Invoices", False, "No auth token available")
            return False
        
        success, response_data, status_code = self.make_request("GET", "/invoices")
        
        if success and isinstance(response_data, list):
            self.log_test(
                "Get Invoices", 
                True, 
                f"Retrieved {len(response_data)} invoices", 
                {"count": len(response_data)}
            )
            return True
        else:
            self.log_test(
                "Get Invoices", 
                False, 
                f"Failed to get invoices. Status: {status_code}", 
                response_data
            )
            return False
    
    def test_dashboard_stats(self):
        """Test dashboard statistics"""
        if not self.auth_token:
            self.log_test("Dashboard Stats", False, "No auth token available")
            return False
        
        success, response_data, status_code = self.make_request("GET", "/stats/dashboard")
        
        if success and isinstance(response_data, dict):
            stats_summary = {
                "total_products": response_data.get("total_products", 0),
                "total_categories": response_data.get("total_categories", 0),
                "total_invoices": response_data.get("total_invoices", 0),
                "monthly_sales": response_data.get("monthly_sales", 0),
                "low_stock_products": response_data.get("low_stock_products", 0)
            }
            self.log_test(
                "Dashboard Stats", 
                True, 
                f"Dashboard stats retrieved successfully", 
                stats_summary
            )
            return True
        else:
            self.log_test(
                "Dashboard Stats", 
                False, 
                f"Failed to get dashboard stats. Status: {status_code}", 
                response_data
            )
            return False
    
    def run_all_tests(self):
        """Run all tests in the correct order"""
        print(f"🚀 Starting Backend API Tests for Sistema de Facturación e Inventario")
        print(f"📍 Base URL: {self.base_url}")
        print("=" * 80)
        
        # Authentication Tests
        print("\n🔐 AUTHENTICATION TESTS")
        print("-" * 40)
        auth_success = True
        auth_success &= self.test_auth_register()
        auth_success &= self.test_auth_login()
        auth_success &= self.test_auth_me()
        
        if not auth_success:
            print("\n❌ Authentication tests failed. Cannot proceed with protected endpoints.")
            return self.generate_summary()
        
        # Categories Tests
        print("\n📁 CATEGORIES TESTS")
        print("-" * 40)
        self.test_create_category()
        self.test_get_categories()
        
        # Products Tests
        print("\n📦 PRODUCTS TESTS")
        print("-" * 40)
        self.test_create_product()
        self.test_get_products()
        self.test_get_product_by_id()
        
        # Invoices Tests
        print("\n🧾 INVOICES TESTS")
        print("-" * 40)
        self.test_create_invoice()
        self.test_get_invoices()
        
        # Statistics Tests
        print("\n📊 STATISTICS TESTS")
        print("-" * 40)
        self.test_dashboard_stats()
        
        return self.generate_summary()
    
    def generate_summary(self):
        """Generate test summary"""
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result['success'])
        failed_tests = total_tests - passed_tests
        
        print("\n" + "=" * 80)
        print("📋 TEST SUMMARY")
        print("=" * 80)
        print(f"Total Tests: {total_tests}")
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%" if total_tests > 0 else "0%")
        
        if failed_tests > 0:
            print(f"\n❌ FAILED TESTS:")
            for result in self.test_results:
                if not result['success']:
                    print(f"   • {result['test']}: {result['details']}")
        
        print(f"\n🔗 Created Resources:")
        for resource_type, resource_id in self.created_resources.items():
            if resource_id:
                print(f"   • {resource_type}: {resource_id}")
        
        return {
            'total_tests': total_tests,
            'passed_tests': passed_tests,
            'failed_tests': failed_tests,
            'success_rate': (passed_tests/total_tests)*100 if total_tests > 0 else 0,
            'results': self.test_results,
            'created_resources': self.created_resources
        }

def main():
    """Main function to run tests"""
    tester = APITester()
    summary = tester.run_all_tests()
    
    # Exit with appropriate code
    if summary['failed_tests'] > 0:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == "__main__":
    main()